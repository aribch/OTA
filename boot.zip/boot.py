# settings
VERSION = 3
GROUP = 1
#try new cod
# actions
print('>> Version {} is booting.'.format(VERSION))
