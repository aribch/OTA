# settings
VERSION = 3
GROUP = 1

# actions
print('>> Version {} is booting.'.format(VERSION))
